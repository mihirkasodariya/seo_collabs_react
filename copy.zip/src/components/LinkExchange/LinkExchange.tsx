import { ExternalLink, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { getLinkExchangeList, type WebsiteData } from "../../api/linkExchange/linkExchange";

interface LayoutContext {
    setPageTitle: (title: string) => void;
}

export function LinkExchange() {
    const { setPageTitle } = useOutletContext<LayoutContext>();

    useEffect(() => {
        setPageTitle("Link Exchange");
        loadWebsites();
    }, []);

    // States
    const [websites, setWebsites] = useState<WebsiteData[]>([]);
    const [search, setSearch] = useState("");
    const [type, setType] = useState("");
    const [category, setCategory] = useState("");
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [typesList, setTypesList] = useState<string[]>([]);
    const [categoriesList, setCategoriesList] = useState<string[]>([]);
    const limit = 4;

    // Fetch websites
    const loadWebsites = async () => {
        try {
            const response = await getLinkExchangeList({ search, type, category, page, limit });
            if (response.success) {
                const records: WebsiteData[] = response.data.records;
                setWebsites(records);
                setTotalPages(response.data.totalPages);

                // Dynamically get types and categories
                const types = Array.from(new Set(records.map(item => item.type))).sort();
                setTypesList(types);
                const categories = Array.from(new Set(records.flatMap(item => item.Categories))).sort();
                setCategoriesList(categories);
            }
        } catch (err) {
            console.error(err);
        }
    };

    // Load websites on mount and when filters/page change
    useEffect(() => {
        setPage(1); // reset page on filter change
    }, [search, type, category]);

    useEffect(() => {
        loadWebsites();
    }, [search, type, category, page]);

    useEffect(() => {
        setPage(1);
        setPage(1);
    }, []);

    return (
        <div className="mx-auto flex flex-col px-4 md:px-0">

            {/* Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4 md:mb-6">
                <h1 className="text-2xl font-bold text-gray-900">Link Exchange</h1>
                <button className="bg-teal-700 text-white cursor-pointer px-3 py-1.5 md:px-4 md:py-2 rounded-lg flex items-center gap-2 hover:bg-teal-800 whitespace-nowrap text-sm md:text-base">
                    My Exchanges
                </button>
            </div>

            {/* Filters */}
            <div className="p-7 border border-[#077a7d] mb-6 rounded-xl">
                <div className="flex flex-col md:flex-row gap-2 md:gap-4">

                    {/* Search */}
                    <div className="relative flex-1">
                        <input
                            type="text"
                            placeholder="Search websites or categories..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="w-full border border-[#077a7d] rounded px-4 py-2 pl-10 focus:outline-none focus:ring-1 focus:ring-teal-700"
                        />
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                    </div>

                    {/* Type dropdown */}
                    <select
                        value={type}
                        onChange={(e) => setType(e.target.value)}
                        className="border border-[#077a7d] cursor-pointer rounded-lg px-4 py-2 focus:outline-none focus:ring-1 focus:ring-teal-700"
                    >
                        <option value="">All Types</option>
                        {typesList.map((t) => (
                            <option key={t} value={t}>{t}</option>
                        ))}
                    </select>

                    {/* Category dropdown */}
                    <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="border border-[#077a7d] rounded-lg px-4 py-2 cursor-pointer focus:outline-none focus:ring-1 focus:ring-teal-700"
                    >
                        <option value="">All Categories</option>
                        {categoriesList.map((c) => (
                            <option key={c} value={c}>{c}</option>
                        ))}
                    </select>

                    {/* Clear filters */}
                    <button
                        onClick={() => {
                            setSearch("");
                            setType("");
                            setCategory("");
                        }}
                        className="border border-[#077a7d] px-4 py-2 cursor-pointer rounded-lg hover:bg-[#63d9db] transition-colors"
                    >
                        Clear Filters
                    </button>
                </div>
            </div>

            {/* Website list */}
            <div className="pb-8 space-y-4">
                {websites.length === 0 ? (
                    <p>No results found.</p>
                ) : (
                    websites.map((item) => (
                        <div
                            key={item._id}
                            className="border border-[#077a7d] rounded-lg p-4 flex flex-col md:flex-row justify-between items-start md:items-center hover:shadow-lg transition"
                        >
                            <div className="flex-1">
                                <a
                                    href={item.url.startsWith("http") ? item.url : `https://${item.url}`}
                                    target="_blank"
                                    className="text-teal-700 font-semibold flex items-center gap-1 hover:underline"
                                >
                                    <ExternalLink size={16} />
                                    {item.url}
                                </a>
                                <p className="text-black mt-1">
                                    <span className="font-semibold">Type:</span> {item.type}
                                </p>
                                <p className="text-black mt-1">
                                    <span className="font-semibold">Categories:</span> {item.Categories.join(", ")}
                                </p>
                                <p className="text-black mt-1">
                                    <span className="font-semibold">Owner:</span> {item.userName || "N/A"}
                                </p>
                            </div>
                            <button className="bg-teal-700 text-white cursor-pointer px-3 py-1.5 md:px-4 md:py-2 rounded-lg flex items-center gap-2 hover:bg-teal-800 whitespace-nowrap text-sm md:text-base">
                                Request Exchange
                            </button>
                        </div>
                    ))
                )}
            </div>

            {/* Pagination */}
            {websites.length > 0 && totalPages > 1 && (
                <div className="flex justify-center items-center gap-2">
                    {/* Previous button */}
                    <button
                        onClick={() => setPage(page > 1 ? page - 1 : 1)}
                        className="px-3 py-1 border border-[#077a7d] rounded bg-white text-black hover:bg-teal-100"
                    >
                        Previous
                    </button>

                    {/* Page numbers */}
                    <div className="flex gap-2 mx-2">
                        {Array.from({ length: totalPages }, (_, i) => (
                            <button
                                key={i + 1}
                                onClick={() => setPage(i + 1)}
                                className={`px-3 py-1 border border-[#077a7d] rounded ${page === i + 1
                                    ? "bg-teal-700 text-white"
                                    : "bg-white text-black hover:bg-teal-100"
                                    }`}
                            >
                                {i + 1}
                            </button>
                        ))}
                    </div>

                    {/* Next button */}
                    <button
                        onClick={() => setPage(page < totalPages ? page + 1 : totalPages)}
                        className="px-3 py-1 border border-[#077a7d] rounded bg-white text-black hover:bg-teal-100"
                    >
                        Next
                    </button>
                </div>
            )}

        </div>
    );
}

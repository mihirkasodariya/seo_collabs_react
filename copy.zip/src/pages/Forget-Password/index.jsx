import { ForgetPassword } from "../../components/Forget-Password/Forget-Password";

const ForgetPasswordPage = () => {
    return (
        <>
            <ForgetPassword />
        </>
    );
};

export default ForgetPasswordPage;
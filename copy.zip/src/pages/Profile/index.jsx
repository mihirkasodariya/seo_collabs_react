import { Profile } from "../../components/Profile/Profile";

const ProfilePage = () => {
    return (
        <>
            <Profile />
        </>
    );
};

export default ProfilePage;
import { Register } from "../../components/Register/Register";

const RegisterPage = () => {

    return (
        <>
            <Register />
        </>
    );
};

export default RegisterPage;
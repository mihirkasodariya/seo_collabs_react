import { LinkExchange } from "../../components/LinkExchange/LinkExchange";

const LinkExchangePage = () => {
    return (
        <>
            <LinkExchange />
        </>
    );
};

export default LinkExchangePage;
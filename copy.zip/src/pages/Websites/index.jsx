import { Websites } from "../../components/Websites/Websites";

const WebsitesPage = () => {
    return (
        <>
            <Websites />
        </>
    );
};

export default WebsitesPage;
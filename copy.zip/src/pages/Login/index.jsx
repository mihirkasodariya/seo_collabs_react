import { Login } from "../../components/Login/Login";

const SignUpPage = () => {
    return (
        <>
            <Login />
        </>
    );
};

export default SignUpPage;